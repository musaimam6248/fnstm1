<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_login('department');
redirect('department/monthly_kpi.php');
