@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-offline.ps1" %*
